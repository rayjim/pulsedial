$Base = Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Force -Path "$Base\raw\nikkei" | Out-Null
New-Item -ItemType Directory -Force -Path "$Base\raw\aum" | Out-Null
Write-Host "Downloads may fail on corporate networks. If so, use .url shortcuts in 06_manual_download_links."
Write-Host "1/22 Historical component changes"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/file/history_of_nikkei_stock_average_component_changes_en.pdf" -OutFile "$Base\raw\nikkei\Historical_component_changes.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/file/history_of_nikkei_stock_average_component_changes_en.pdf" }
Write-Host "2/22 Projected full PAF list as of 2021-10-01"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20210906E_3.pdf" -OutFile "$Base\raw\nikkei\Projected_full_PAF_list_as_of_2021-10-01.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20210906E_3.pdf" }
Write-Host "3/22 2019 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20190904E_1.pdf" -OutFile "$Base\raw\nikkei\2019_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20190904E_1.pdf" }
Write-Host "4/22 2020 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20200901E_1.pdf" -OutFile "$Base\raw\nikkei\2020_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20200901E_1.pdf" }
Write-Host "5/22 2021 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20210906E_1.pdf" -OutFile "$Base\raw\nikkei\2021_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20210906E_1.pdf" }
Write-Host "6/22 2022 Apr extraordinary"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20220301E_1.pdf" -OutFile "$Base\raw\nikkei\2022_Apr_extraordinary.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20220301E_1.pdf" }
Write-Host "7/22 2022 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20220905E_1.pdf" -OutFile "$Base\raw\nikkei\2022_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20220905E_1.pdf" }
Write-Host "8/22 2023 Spring"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20230303E_1.pdf" -OutFile "$Base\raw\nikkei\2023_Spring.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20230303E_1.pdf" }
Write-Host "9/22 2023 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20230904E_1.pdf" -OutFile "$Base\raw\nikkei\2023_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20230904E_1.pdf" }
Write-Host "10/22 2024 Spring"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20240304E_1.pdf" -OutFile "$Base\raw\nikkei\2024_Spring.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20240304E_1.pdf" }
Write-Host "11/22 2024 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20240904E_1.pdf" -OutFile "$Base\raw\nikkei\2024_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20240904E_1.pdf" }
Write-Host "12/22 2025 Spring"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20250305E_1.pdf" -OutFile "$Base\raw\nikkei\2025_Spring.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20250305E_1.pdf" }
Write-Host "13/22 2025 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20250908E_1.pdf" -OutFile "$Base\raw\nikkei\2025_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20250908E_1.pdf" }
Write-Host "14/22 2026 Spring"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/en/nkave/archives/news/20260305E_1.pdf" -OutFile "$Base\raw\nikkei\2026_Spring.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/en/nkave/archives/news/20260305E_1.pdf" }
Write-Host "15/22 2026 Autumn"
try { Invoke-WebRequest -Uri "https://indexes.nikkei.co.jp/nkave/archives/news/20260904J_1.pdf" -OutFile "$Base\raw\nikkei\2026_Autumn.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://indexes.nikkei.co.jp/nkave/archives/news/20260904J_1.pdf" }
Write-Host "16/22 NRI Fundmark 2025-08"
try { Invoke-WebRequest -Uri "https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202509.pdf" -OutFile "$Base\raw\aum\NRI_Fundmark_2025-08.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202509.pdf" }
Write-Host "17/22 NRI Fundmark 2025-12"
try { Invoke-WebRequest -Uri "https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202601.pdf" -OutFile "$Base\raw\aum\NRI_Fundmark_2025-12.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202601.pdf" }
Write-Host "18/22 NRI Fundmark 2026-01"
try { Invoke-WebRequest -Uri "https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202602.pdf" -OutFile "$Base\raw\aum\NRI_Fundmark_2026-01.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202602.pdf" }
Write-Host "19/22 NRI Fundmark 2026-03"
try { Invoke-WebRequest -Uri "https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202604.pdf" -OutFile "$Base\raw\aum\NRI_Fundmark_2026-03.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202604.pdf" }
Write-Host "20/22 NRI Fundmark 2026-05"
try { Invoke-WebRequest -Uri "https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202606.pdf" -OutFile "$Base\raw\aum\NRI_Fundmark_2026-05.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/jp/knowledge/report/files/fundmarkreport_202606.pdf" }
Write-Host "21/22 Historical NRI Fundmark 2021-09"
try { Invoke-WebRequest -Uri "https://www.nri.com/-/media/Corporate/jp/Files/PDF/knowledge/report/fis/ids/fundmarkreport_202109.pdf" -OutFile "$Base\raw\aum\Historical_NRI_Fundmark_2021-09.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/-/media/Corporate/jp/Files/PDF/knowledge/report/fis/ids/fundmarkreport_202109.pdf" }
Write-Host "22/22 Historical NRI Fundmark 2021-10"
try { Invoke-WebRequest -Uri "https://www.nri.com/-/media/Corporate/jp/Files/PDF/knowledge/report/fis/ids/fundmarkreport_202110.pdf" -OutFile "$Base\raw\aum\Historical_NRI_Fundmark_2021-10.pdf" -UseBasicParsing } catch { Write-Warning "FAILED: https://www.nri.com/-/media/Corporate/jp/Files/PDF/knowledge/report/fis/ids/fundmarkreport_202110.pdf" }
