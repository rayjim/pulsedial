# Nikkei 225 Historical Master Pack — 2019 to 2026

This package is intended as a handoff dataset for an internal Master AI / Coding Agent workflow.

## Coverage
- Official Nikkei review/event references: 2019 Autumn through 2026 Autumn
- Explicit extraordinary 2022-04 event
- Methodology transition notes
- Known PAF corporate-action events
- Capping-event registry
- Non-ETF AUM hard anchors
- Low/base/high historical non-ETF AUM scenarios
- Source registries with direct URLs
- Manual download shortcuts and scripts
- Master AI handoff prompt

## Most important files
1. `01_index_events/nikkei225_event_master_2019_2026.csv`
2. `01_index_events/nikkei225_methodology_change_log.csv`
3. `02_paf_capping/known_paf_event_registry.csv`
4. `02_paf_capping/capping_event_registry.csv`
5. `03_aum/non_etf_aum_hard_anchors.csv`
6. `03_aum/non_etf_aum_event_scenarios_2019_2026.csv`
7. `04_source_manifests/nikkei_official_source_registry.csv`
8. `05_master_ai_handoff/MASTER_AI_HANDOFF.md`
9. `05_master_ai_handoff/MASTER_AI_START_PROMPT.txt`

## Important interpretation
The package does NOT claim that early historical non-ETF AUM is exact.
The reason for supplying low/base/high is to make the first historical impact study robust to AUM uncertainty.

For production-quality AUM:
- pull ETF AUM from Bloomberg;
- use internal Morningstar Direct if available for historical fund AUM;
- use NRI Fundmark aggregates as external calibration;
- reconcile fund wrappers/feeders before summing.

## Recommended first backtest window
Start with 2023–2026.
This avoids the legacy pre-PAF methodology and gives cleaner factor reconstruction.
Once fully reconciled, extend to 2021–2022 and finally 2019–2020 using a legacy-methodology adapter.

## Raw official files
Publisher PDFs are not embedded in this package.
Use:
- `06_manual_download_links/`
- `07_scripts/download_sources.ps1`
- `07_scripts/download_sources.sh`

This is intentional so the corporate environment can acquire source files directly under its own access/licensing conditions.
