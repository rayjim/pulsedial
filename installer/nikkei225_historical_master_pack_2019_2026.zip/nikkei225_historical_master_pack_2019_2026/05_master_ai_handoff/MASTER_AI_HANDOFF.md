# Handoff to Master AI — Nikkei 225 Historical Rebalance Backtest

## Objective
Build a point-in-time historical Nikkei 225 rebalance backtest using this pack plus internal Bloomberg data.

## Source hierarchy
1. Nikkei Official = index truth.
2. Bloomberg = market truth (price, volume, ADV, identifiers; ETF AUM from Bloomberg).
3. NRI Fundmark / Morningstar / manager pages = non-ETF AUM calibration.
4. Never silently replace Nikkei official reference data with third-party data.

## Critical methodology boundary
- Before 2021-10-01: Nikkei uses legacy presumed-par-value adjustment.
- From 2021-10-01: use PAF.
- Capping must be modeled as a separate point-in-time factor event.
- Extraordinary constituent events must be included; do not only ingest spring/autumn reviews.

## Recommended historical workflow
For each event:
1. Reconstruct pre-event basket point-in-time.
2. Apply all membership events through the relevant timestamp.
3. Reconstruct factor state (legacy factor or PAF, plus capping ratio).
4. Pull Bloomberg close price for pre-event and effective-date calculations.
5. Compute old and pro-forma/new weights.
6. Validate using Nikkei official monthly weights / Daily Summary top weights where possible.
7. Pull plain-vanilla ETF AUM from Bloomberg at that event date.
8. Add non-ETF AUM using `03_aum/non_etf_aum_event_scenarios_2019_2026.csv`.
9. Run low/base/high flow sensitivity.
10. Compute shares, JPY flow, %ADV, auction metrics and subsequent market impact.

## AUM caveat
The event AUM file is deliberately a research proxy:
- 2025-08 onward has hard NRI aggregate anchors.
- 2019–2024 values are estimates with wide bands.
- If internal Morningstar Direct or historical fund NAV/AUM is available, replace the estimates.
- ETF feeder wrappers must not be double-counted if their underlying ETF is already in Bloomberg ETF AUM.

## Data quality gates
Do not advance to impact research until:
- basket size and membership reconcile,
- weights sum to ~100%,
- major weight differences are explained,
- all factor/corporate-action events near the review are point-in-time consistent,
- source provenance is retained.

## First Coding Agent task recommended
Inspect the existing repository and ingest this pack WITHOUT redesigning the project. Map:
- event master -> Nikkei provider/event model
- PAF/capping registry -> point-in-time factor state
- AUM scenario file -> AUM engine input
- source registries -> provenance metadata

Then produce a plan to backtest 2023–2026 first, because the PAF methodology is stable and data quality is much better. After validation, extend backward to 2021/2020/2019 with the legacy methodology adapter.
